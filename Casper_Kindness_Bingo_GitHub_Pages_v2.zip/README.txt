CASPER ACTS OF KINDNESS BINGO — GITHUB PAGES

Publish:
1. Open the GitHub repository you want to use.
2. Upload index.html to the repository's root (top-level) folder.
3. Commit the change to the main branch.
4. In Settings > Pages, select Deploy from a branch.
5. Select the main branch and /(root), then Save.
6. After GitHub finishes publishing, copy the Pages URL and share it in Slack.

Each person uses the same public page link. Checkmarks are saved in that person's
browser on that device. They are not centrally visible to other players and do not
automatically transfer to another device/browser.
